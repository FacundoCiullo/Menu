// src/index.js
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css'; // tus estilos si existen

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);